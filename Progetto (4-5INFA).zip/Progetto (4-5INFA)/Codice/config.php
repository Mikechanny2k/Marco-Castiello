<?php
$config = [
    'mysql_host' => 'localhost',
    'mysql_user' => 'root',
    'mysql_password' => null,
    'mysql_db' => 'Prato_Crescita_Fiore'];

?>