<?php
require_once 'config.php';
$conn = new mysqli(
  $config['mysql_host'],
  $config['mysql_user'],
  $config['mysql_password'],
  $config['mysql_db']
);
if($conn->connect_error)
die("Errore connesione al database.<br>");

$sql = "SELECT Nome, PunteggioMax FROM Giocatore WHERE IDGiocatore=1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  
  while($row = $result->fetch_assoc()) {
    echo "Nome: " . $row["Nome"]. " - Punteggio massimo: " . $row["PunteggioMax"]. "<br>";
  }
} else {
  echo "Nessun risultato";
  $stmt->close();
}
?>
