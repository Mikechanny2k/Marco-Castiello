//Made by Di Grigoli Francesco, Bini Alberto, Attina' Mirko


/*
  --LAVORO NON FINITO DEL TUTTO--
  UN BUON 95% FATTO, IL CSS NON È ADATTABILE, E VA FATTA UN FIX DI ALCUNI METODI IN JAVASCRIPT
*/


let microfono = { nome: "Microfono", quantita: 0};
let vanga = { nome: "Vanga", quantita: 0 };
let cuore = { nome: "Cuore", quantita: 0 };
let sole = { nome: "Sole", quantita: 0 };
let acqua = { nome: "Acqua", quantita: 0 };
let occhiali = { nome: "Occhiali", quantita: 0 };

let margherita =  { nome: "Margherita", quantita: 0};
let tulipano =  { nome: "Tulipano", quantita: 0};
let girasole =  { nome: "Girasole", quantita: 0};
let rosa =  { nome: "Rosa", quantita: 0};

let intervalId;
let startTime;
let tempoAvviato = false;
let giorno = true;
let primaVolta = true;
let shopCliccato = false;
let valoreIniziale = 100;
let ricorda = "";
let click = false;


//AUDIO

// Ottieni il riferimento all'elemento audio
let audio = new Audio("music/canzonegioco.mp3");

//FUNZIONI PER L'AUDIO
function playSong() {
  console.log("Canzone avviata");
  audio.play(); 
}
function pauseSong() {
  console.log("Canzone spenta");
  audio.pause();
}


//Classe padre Fiore

class Fiore {
  static quantitaMinimaAcqua = 20;

  constructor() {
    this.contatoreAcqua = 0;
    this.vita = 0;//0 vivo,1 morto
  }

  controlloAcqua() {
    if (this.contatoreAcqua >= quantitaMinimaAcqua) {
      return true;
    } else {
      this.vita = 1; // Poca acqua, il fiore muore
      return false;
    }
  }
}


//Classe Margherita Canterina
class MargheritaCanterina extends Fiore {

  constructor() {
    super();
  }

}

//Classe Tulipano Triste
class TulipanoTriste extends Fiore {
  constructor() {
    super();
  }

}

//Classe Rosa Teppisa
class RosaTeppista extends Fiore {
  constructor() {
    super();
  }

}

//Classe Girasole Burlone
class GirasoleBurlone extends Fiore {
  constructor() {
    super();
  }

}


//VETTORI
// Vettore B1
let vetB1 = [
  new MargheritaCanterina(),
  new TulipanoTriste(),
  new GirasoleBurlone(),
  new RosaTeppista()
];

// Vettore B2
let vetB2 = [
  new MargheritaCanterina(),
  new TulipanoTriste(),
  new GirasoleBurlone(),
  new RosaTeppista()
];

// Vettore B3
let vetB3 = [
  new MargheritaCanterina(),
  new TulipanoTriste(),
  new GirasoleBurlone(),
  new RosaTeppista()
];

// Vettore B4
let vetB4 = [
  new MargheritaCanterina(),
  new TulipanoTriste(),
  new GirasoleBurlone(),
  new RosaTeppista()
];

// Vettore B5
let vetB5 = [
  new MargheritaCanterina(),
  new TulipanoTriste(),
  new GirasoleBurlone(),
  new RosaTeppista()
];

// Vettore B6
let vetB6 = [
  new MargheritaCanterina(),
  new TulipanoTriste(),
  new GirasoleBurlone(),
  new RosaTeppista()
];

// Vettore B7
let vetB7 = [
  new MargheritaCanterina(),
  new TulipanoTriste(),
  new GirasoleBurlone(),
  new RosaTeppista()
];

// Vettore B8
let vetB8 = [
  new MargheritaCanterina(),
  new TulipanoTriste(),
  new GirasoleBurlone(),
  new RosaTeppista()
];

// Vettore B9
let vetB9 = [
  new MargheritaCanterina(),
  new TulipanoTriste(),
  new GirasoleBurlone(),
  new RosaTeppista()
];

// Vettore B10
let vetB10 = [
  new MargheritaCanterina(),
  new TulipanoTriste(),
  new GirasoleBurlone(),
  new RosaTeppista()
];

// Vettore B11
let vetB11 = [
  new MargheritaCanterina(),
  new TulipanoTriste(),
  new GirasoleBurlone(),
  new RosaTeppista()
];

// Vettore B12
let vetB12 = [
  new MargheritaCanterina(),
  new TulipanoTriste(),
  new GirasoleBurlone(),
  new RosaTeppista()
];

// Vettore B13
let vetB13 = [
  new MargheritaCanterina(),
  new TulipanoTriste(),
  new GirasoleBurlone(),
  new RosaTeppista()
];

// Vettore B14
let vetB14 = [
  new MargheritaCanterina(),
  new TulipanoTriste(),
  new GirasoleBurlone(),
  new RosaTeppista()
];

// Vettore B15
let vetB15 = [
  new MargheritaCanterina(),
  new TulipanoTriste(),
  new GirasoleBurlone(),
  new RosaTeppista()
];

// Vettore B16
let vetB16 = [
  new MargheritaCanterina(),
  new TulipanoTriste(),
  new GirasoleBurlone(),
  new RosaTeppista()
];




//SCRIPT PER LO SHOP

//prezzi
let soldi = 100;
let prezzoMicrofono = 10;
let prezzoVanga = 10;
let prezzoCuore = 10;
let prezzoSole = 10;
let prezzoAcqua = 10;
let prezzoOcchiali = 10;

let prezzoMargherita = 10;
let prezzoTulipano = 10;
let prezzoGirasole = 10;
let prezzoRosa = 10;


//FUNZIONE PER COMPRARE GLI ITEM
function compraMicrofono() {
  console.log("soldi prima dell'acquisto: "+soldi);
  if(microfono.quantita >= 9){
    console.log("Hai finito lo spazio nell'inventario");
    microfono.quantita = 9;
  }else{
    if (soldi< prezzoMicrofono) {
      //popup
      console.log("non hai abbastanza soldi");
    } else {
      microfono.quantita+=1;
      soldi -= prezzoMicrofono;
      console.log("Soldi dopo l'acquisto: " + soldi);
    }
  }
}

function compraSole() {
  console.log("soldi prima dell'acquisto: "+soldi);
  if(sole.quantita >= 9){
    console.log("Hai finito lo spazio nell'inventario");
    sole.quantita = 9;
  }else{
    if (soldi< prezzoSole) {
      //popup
      console.log("non hai abbastanza soldi");
    } else {
      sole.quantita+=1;
      soldi-=  prezzoSole;
    }
  }
}

function compraCuore() {
  console.log("soldi prima dell'acquisto: "+soldi);
  if(cuore.quantita >= 9){
    console.log("Hai finito lo spazio nell'inventario");
    cuore.quantita = 9;
  }else{
    if (soldi< prezzoCuore) {
      //popup
      console.log("non hai abbastanza soldi");
    } else {
      cuore.quantita+=1;
      soldi-=  prezzoCuore;
    }
  }
}

function compraOcchiali() {
  console.log("soldi prima dell'acquisto: "+soldi);
  if(occhiali.quantita >= 9){
    console.log("Hai finito lo spazio nell'inventario");
    occhiali.quantita = 9;
  }else{
    if (soldi < prezzoOcchiali) {
      //popup
      console.log("non hai abbastanza soldi");
    } else {
      occhiali.quantita+=1;
      soldi-=  prezzoOcchiali;
    }
  }
}

function compraVanga() {
  console.log("soldi prima dell'acquisto: "+soldi);
  if(vanga.quantita >= 9){
    console.log("Hai finito lo spazio nell'inventario");
    vanga.quantita = 9;
  }else{
    if (soldi < prezzoVanga) {
      //popup
      console.log("non hai abbastanza soldi");
    } else {
      vanga.quantita+=1;
      soldi-=  prezzoVanga;
    }
  }
}

function compraAcqua() {
  console.log("soldi prima dell'acquisto: "+soldi);
  if(acqua.quantita >= 100){
    console.log("Hai finito lo spazio nell'inventario");
    acqua.quantita = 100;
  }else{
    if (soldi < prezzoAcqua) {
      //popup
      console.log("non hai abbastanza soldi");
    } else {
      acqua.quantita += 50;
      soldi -=  prezzoAcqua;
    }
  }
}


//FUNZIONE PER COMPRARE LE PIANTE
function compraMargherita() {
  console.log("soldi prima dell'acquisto: "+soldi);
  if(margherita.quantita >= 9){
    console.log("Hai finito lo spazio nell'inventario");
    margherita.quantita = 9;
  }else{
    if (soldi < prezzoMargherita) {
      console.log("non hai abbastanza soldi");
    } else {
      margherita.quantita += 1;
      console.log("Quantita di margherita: " + margherita.quantita);
      soldi -= prezzoMargherita;
      console.log("soldi dopo l'acquisto: "+soldi);
    }
  }
}

function compraTulipano() {
  console.log("soldi prima dell'acquisto: "+soldi);
  if(tulipano.quantita >= 9){
    console.log("Hai finito lo spazio nell'inventario");
    tulipano.quantita = 9;
  }else{
    if (soldi< prezzoTulipano) {
      //popup
      console.log("non hai abbastanza soldi");
    } else {
      tulipano.quantita+=1;
      soldi -=  prezzoTulipano;
    }
  }
}


function compraGirasole() {
  console.log("soldi prima dell'acquisto: "+soldi);
  if(girasole.quantita >= 9){
    console.log("Hai finito lo spazio nell'inventario");
    girasole.quantita = 9;
  }else{
    if (soldi< prezzoGirasole) {
      //popup
      console.log("non hai abbastanza soldi");
    } else {
      girasole.quantita+=1;
      soldi -=  prezzoGirasole;
    }
  }
}

function compraRosa() {
  console.log("soldi prima dell'acquisto: "+soldi);
  if(rosa.quantita >= 9){
    console.log("Hai finito lo spazio nell'inventario");
    rosa.quantita = 9;
  }else{
    if (soldi< prezzoRosa) {
      //popup
      console.log("non hai abbastanza soldi");
    } else {
      rosa.quantita+=1;
      soldi-=  prezzoRosa;
    }
  }
}


//SCRIPT PER INDEX.HTML
//Funzione per resettare il gioco
function resettaGioco(valoreIniziale) {
  console.log("Nuova partita");
  let elemSoldi = document.getElementById("soldiVisualizza");
  soldi = valoreIniziale;
  elemSoldi.textContent = "Soldi: " + valoreIniziale;
  clearInterval(intervalId);
  startTime = Math.floor(Date.now() / 1000);
  document.getElementById("tempo").textContent = 'Tempo trascorso: 0 secondi';
  document.getElementById("tempoGiorno").textContent = 'Tempo che manca al giorno: 10 secondi';
  giorno = false;
  cambiaGiornoNotte();
  tempoAvviato = false;

  //Vado a resettare tutti i campi
  let bottoni = document.querySelectorAll(".bottone");
  for(let i = 0; i< bottoni.length; i++){
    let bottone = bottoni[i];
    bottone.style.background = "green";
  }

  //Vado a resettare tutti gli item e le piante
  margherita.quantita = 0;
  tulipano.quantita = 0;
  girasole.quantita = 0;
  rosa.quantita = 0;

  microfono.quantita = 0;
  cuore.quantita = 0;
  sole.quantita = 0;
  occhiali.quantita = 0;
  acqua.quantita = 0;
  vanga.quantita = 0;

  

}

//Funzione per avviare il tempo -----DA FINIRE! NON FUNZIONA CORRETTAMENTE
function avviaTempo() {
  //Significa che lo shop è stato cliccato e che quindi siamo dentro lo shop
  if(shopCliccato == false){
    console.log("Faccio scorrere il tempo....");
    console.log('Inizio misurazione del tempo...');
    let startTime = Math.floor(Date.now() / 1000);
    let secondi = 10;
    let elapsedTime2 = secondi;

    intervalId = setInterval(function () {
      let currentTime = Math.floor(Date.now() / 1000);
      let elapsedTime = currentTime - startTime;
      elapsedTime2--;

      document.getElementById("tempo").textContent = 'Tempo trascorso: ' + elapsedTime + ' secondi';

      if(giorno == false){
          document.getElementById("tempoGiorno").textContent = 'Tempo che manca alla notte: ' + elapsedTime2 + ' secondi ';
          aumentaSoldi();
      }
      if (giorno == true) {
        document.getElementById("tempoGiorno").textContent = 'Tempo che manca al giorno: ' + elapsedTime2 + ' secondi ';
      }

      if (elapsedTime2 <= 0) {
        cambiaGiornoNotte();
        elapsedTime2 = secondi;
      }  

    }, 1000);
  
  }
}

//GIOCO
function myGames() {
  if (!tempoAvviato) {
    avviaTempo();
    tempoAvviato = true;
  }
  
}

//FUNZIONI CHE VANNO AD AUMENTARE I SOLDI IN BASE ALLE PIANTE CHE CI SONO
function aumentaSoldi(){
  //Vado ad aumentare i soldi in base a quante piante sono nei bottoni
  let bottoni = document.querySelectorAll(".bottone");
  for(let i = 0; i< bottoni.length; i++){
    let bottone = bottoni[i];
    if(bottone.style.backgroundImage.includes('img/shop/margherita.png')){
      soldi += 1;
    }
    if(bottone.style.backgroundImage.includes('img/shop/tulipano.png')){
      soldi += 2;
    }
    if(bottone.style.backgroundImage.includes('img/shop/girasole.png')){
      soldi += 3;
    }
    if(bottone.style.backgroundImage.includes('img/shop/rosa.png')){
      soldi += 4;
    }
  }
}

//FUNZIONI PER PIANTARE LE PIANTE

//Funzione di supporto Margherita
function chiamaMargherita(margheritaVett,bottone){

  //MARGHERITA
  if(ricorda == "margherita"){
    //Vado a verificare se c'è già un'altro seme
    if(bottone.style.backgroundImage.includes('img/semi/semeMargherita.png')){
      console.log("Errore, ho già un seme di margherita");
      margherita.quantita++;
    }else{
      if(bottone.style.backgroundImage.includes('img/semi/semeTulipano.png')){
        console.log("Errore, ho già un seme di Tulipano");
        margherita.quantita++;
      
      }else{
        if(bottone.style.backgroundImage.includes('img/semi/semeGirasole.png')){
          console.log("Errore, ho già un seme di Girasole");
          margherita.quantita++;
        }else{
          if(bottone.style.backgroundImage.includes('img/semi/semeRosa.png')){
            console.log("Errore, ho già un seme di Rosa");
            margherita.quantita++;
          }else{
            //Vado a verificare se c'è già un'altra pianta
            if(bottone.style.backgroundImage.includes('img/shop/margherita.png')){
              console.log("Ho già una margheritaCanterina")
              margherita.quantita++;
            }else{
              if(bottone.style.backgroundImage.includes('img/shop/tulipano.png')){
                console.log("Ho già un TulipanoTriste");
                margherita.quantita++;
              }else{
                if(bottone.style.backgroundImage.includes('img/shop/girasole.png')){
                  console.log("Ho già un girasoleBurlone");
                  margherita.quantita++;
                }else{
                  if(bottone.style.backgroundImage.includes('img/shop/rosa.png')){
                    console.log("Ho già una rosaTeppista");
                    margherita.quantita++;
                  }else{
                    //IL CAMPO È VUOTO, VADO AD INSERIRE LA PIANTA
                    if(acqua.quantita > 10 ){
                      //Inserisce la piantina
                      console.log("Inserisce la piantina");
                      bottone.style.backgroundImage = "url('img/semi/semeMargherita.png')";
                      margheritaVett.contatoreAcqua += 10;
                      acqua.quantita -= 10;
                      margheritaVett.quantitaMinimaAcqua = 10;
                    }else{
                      //La quantita d'acqua non è sufficente
                      console.log("Non ho acqua per piantare la pianta");
                      margherita.quantita++;
                    } 
                  }
                }
              }
            }
          }
        }
      }
    }
  //VADO AD EVOLVERE LA PIANTA, QUINDI RICORDA SARÀ UGUALE A MICROFONO
  }else{
    //Vado a controllare se ricorda è un "cuore"
    if(ricorda == "cuore"){
      cuore.quantita++;
    }else{
      //Vado a controllare se ricorda è "sole"
      if(ricorda == "sole"){
        sole.quantita++;
      }else{
        //Vado a controllare se ricorda è "occhiali"
        if(ricorda == "occhiali"){
          occhiali.quantita++;
        }else{
          //Se c'è già una pianta Margherita, vado ad aumentare microfono.
          if(ricorda == "microfono" && bottone.style.backgroundImage.includes('img/shop/margherita.png')){
            console.log("C'è già una MargheritaCanterina");
            microfono.quantita++;
          }else{
            //Se ho un seme Margherita e ricorda è uguale a microfono vado avanti
            if(ricorda == "microfono" && bottone.style.backgroundImage.includes('img/semi/semeMargherita.png')){
              //Se l'acqua per evolverla è sufficente la evolvo
              if(margheritaVett.controlloAcqua != true){
                bottone.style.backgroundImage = "url('img/shop/margherita.png')";
                margheritaVett.contatoreAcqua += 10;
                acqua.quantita -=10;
                console.log("Evolve");
              }else{
                //L'acqua non è sufficente, quindi aumento microfono.
                console.log("Non hai acqua");
                microfono.quantita++;
              }
            }
          }
        }
      }
    }
  }
}


//Funzione di supporto Tulipano
function chiamaTulipano(tulipanoVett,bottone){
  //TULIPANO
  if (ricorda == "tulipano"){
    //Vado a verificare se c'è già un'altro seme
      if(bottone.style.backgroundImage.includes('img/semi/semeMargherita.png')){
        console.log("Errore, ho già un seme di margherita");
        tulipano.quantita++;
      }else{
        if(bottone.style.backgroundImage.includes('img/semi/semeTulipano.png')){
          console.log("Errore, ho già un seme di Tulipano");
          tulipano.quantita++;
        
        }else{
          if(bottone.style.backgroundImage.includes('img/semi/semeGirasole.png')){
            console.log("Errore, ho già un seme di Girasole");
            tulipano.quantita++;
          }else{
            if(bottone.style.backgroundImage.includes('img/semi/semeRosa.png')){
              console.log("Errore, ho già un seme di Rosa");
              tulipano.quantita++;
            }else{
              //Vado a verificare se c'è già un'altra pianta
              if(bottone.style.backgroundImage.includes('img/shop/margherita.png')){
                console.log("Ho già una margheritaCanterina")
                tulipano.quantita++;
              }else{
                if(bottone.style.backgroundImage.includes('img/shop/tulipano.png')){
                  console.log("Ho già un TulipanoTriste");
                  tulipano.quantita++;
                }else{
                  if(bottone.style.backgroundImage.includes('img/shop/girasole.png')){
                    console.log("Ho già un girasoleBurlone");
                    tulipano.quantita++;
                  }else{
                    if(bottone.style.backgroundImage.includes('img/shop/rosa.png')){
                      console.log("Ho già una rosaTeppista");
                      tulipano.quantita++;
                    }else{
                      //IL CAMPO È VUOTO, VADO AD INSERIRE LA PIANTA
                      if (acqua.quantita > 10) {
                        //Inserisce la piantina
                        console.log("Inserisce la piantina");
                        bottone.style.backgroundImage = "url('img/semi/semeTulipano.png')";
                        tulipanoVett.contatoreAcqua += 10;
                        acqua.quantita -= 10;
                      } else {
                        //La quantita d'acqua non è sufficente
                        console.log("Non ho acqua per piantare la pianta");
                        tulipano.quantita++;
                      }
                    }
                  }
                }
              }                
            }
          }
        }
      }
      //VADO AD EVOLVERE LA PIANTA, QUINDI RICORDA SARÀ UGUALE A CUORE
  }else{
    //Vado a controllare se ricorda è "microfono"
    if(ricorda == "microfono"){
      microfono.quantita++;
    }else{
      //Vado a controllare se ricorda è un "cuore"
      if(ricorda == "occhiali"){
        occhiali.quantita++;
      }else{
        //Vado a controllare se ricorda è "sole"
        if(ricorda == "sole"){
          sole.quantita++;
        }else{
          //Se c'è già una pianta Tulipano, vado ad aumentare cuore.
          if (ricorda == "cuore" && bottone.style.backgroundImage.includes('img/shop/tulipano.png')) {
            console.log("C'è già un TulipanoTriste");
            cuore.quantita++;
          } else {
            //Se ho un seme Tulipano e ricorda è uguale a cuore vado avanti
            if (ricorda == "cuore" && bottone.style.backgroundImage.includes('img/semi/semeTulipano.png')) {
              //Se l'acqua per evolverla è sufficiente la evolvo
              if (tulipanoVett.controlloAcqua != true) {
                bottone.style.backgroundImage = "url('img/shop/tulipano.png')";
                tulipanoVett.contatoreAcqua += 10;
                acqua.quantita -= 10;
                console.log("Evolve");
              } else {
                //L'acqua non è sufficiente, quindi aumento cuore.
                console.log("Non hai acqua");
                cuore.quantita++;
              }
            }
          }
        }
      }
    }
  }
}


//Funzione di supporto Girasole
function chiamaGirasole(girasoleVett,bottone){
   //GIRASOLE
   if (ricorda == "girasole"){
    //Vado a verificare se c'è già un'altro seme
    if(bottone.style.backgroundImage.includes('img/semi/semeGirasole.png')){
      console.log("Errore, ho già un seme di Girasole");
      girasole.quantita++;
    }else{
      if(bottone.style.backgroundImage.includes('img/semi/semeMargherita.png')){
        console.log("Errore, ho già un seme di Margherita");
        girasole.quantita++;
      }else{
        if(bottone.style.backgroundImage.includes('img/semi/semeTulipano.png')){
          console.log("Errore, ho già un seme di Tulipano");
          girasole.quantita++;
        }else{
          if(bottone.style.backgroundImage.includes('img/semi/semeRosa.png')){
            console.log("Errore, ho già un seme di Rosa");
            girasole.quantita++;
          }else{
            //Vado a verificare se c'è già un'altra pianta
            if(bottone.style.backgroundImage.includes('img/shop/girasole.png')){
              console.log("Ho già un GirasoleBurlone")
              girasole.quantita++;
            }else{
              if(bottone.style.backgroundImage.includes('img/shop/margherita.png')){
                console.log("Ho già una MargheritaCanterina");
                girasole.quantita++;
              }else{
                if(bottone.style.backgroundImage.includes('img/shop/tulipano.png')){
                  console.log("Ho già un TulipanoTriste");
                  girasole.quantita++;
                }else{
                  if(bottone.style.backgroundImage.includes('img/shop/rosa.png')){
                    console.log("Ho già una RosaTeppista");
                    girasole.quantita++;
                  }else{
                    //IL CAMPO È VUOTO, VADO AD INSERIRE LA PIANTA
                    if(acqua.quantita > 10 ){
                      //Inserisce la piantina
                      console.log("Inserisce la piantina");
                      bottone.style.backgroundImage = "url('img/semi/semeGirasole.png')";
                      girasoleVett.contatoreAcqua += 10;
                      acqua.quantita -= 10;
                      girasoleVett.quantitaMinimaAcqua = 10;
                    }else{
                      //La quantita d'acqua non è sufficiente
                      console.log("Non ho acqua per piantare la pianta");
                      girasole.quantita++;
                    } 
                  }
                }
              }
            }
          }
        }
      }
    }
  //VADO AD EVOLVERE LA PIANTA, QUINDI RICORDA SARÀ UGUALE A SOLE
  }else{
    //Vado a controllare se ricorda è "microfono"
    if(ricorda == "microfono"){
      console.log("UHHH");
      microfono.quantita++;
    }else{
      //Vado a controllare se ricorda è un "cuore"
      if(ricorda == "cuore"){
        cuore.quantita++;
      }else{
        //Vado a controllare se ricorda è "occhiali"
        if(ricorda == "occhiali"){
          occhiali.quantita++;
        }else{
          //Se c'è già una pianta Girasole, vado ad aumentare sole.
          if(ricorda == "sole" && bottone.style.backgroundImage.includes('img/shop/girasole.png')){
            console.log("C'è già un GirasoleBurlone");
            sole.quantita++;
          }else{
            //Se ho un seme Girasole e ricorda è uguale a ole vado avanti
            if(ricorda == "sole" && bottone.style.backgroundImage.includes('img/semi/semeGirasole.png')){
              //Se l'acqua per evolverla è sufficiente la evolvo
              if(girasoleVett.controlloAcqua != true){
                bottone.style.backgroundImage = "url('img/shop/girasole.png')";
                girasoleVett.contatoreAcqua += 10;
                acqua.quantita -=10;
                console.log("Evolve");
              }else{
                //L'acqua non è sufficiente, quindi aumento ole.
                console.log("Non hai acqua");
                sole.quantita++;
              }
            }
          }
        }
      }
    }
  }
}


//Funzione di supporto Rosa
function chiamaRosa(rosaVett,bottone){
  //ROSA
  if (ricorda == "rosa"){
    //Vado a verificare se c'è già un'altro seme
    if(bottone.style.backgroundImage.includes('img/semi/semeRosa.png')){
      console.log("Errore, ho già un seme di Rosa");
      rosa.quantita++;
    }else{
      if(bottone.style.backgroundImage.includes('img/semi/semeMargherita.png')){
        console.log("Errore, ho già un seme di Margherita");
        rosa.quantita++;
      
      }else{
        if(bottone.style.backgroundImage.includes('img/semi/semeTulipano.png')){
          console.log("Errore, ho già un seme di Tulipano");
          rosa.quantita++;
        }else{
          if(bottone.style.backgroundImage.includes('img/semi/semeGirasole.png')){
            console.log("Errore, ho già un seme di Girasole");
            rosa.quantita++;
          }else{
            //Vado a verificare se c'è già un'altra pianta
            if(bottone.style.backgroundImage.includes('img/shop/rosa.png')){
              console.log("Ho già una RosaTeppista")
              rosa.quantita++;
            }else{
              if(bottone.style.backgroundImage.includes('img/shop/margherita.png')){
                console.log("Ho già una MargheritaCanterina");
                rosa.quantita++;
              }else{
                if(bottone.style.backgroundImage.includes('img/shop/tulipano.png')){
                  console.log("Ho già un TulipanoTriste");
                  rosa.quantita++;
                }else{
                  if(bottone.style.backgroundImage.includes('img/shop/girasole.png')){
                    console.log("Ho già un GirasoleBurlone");
                    rosa.quantita++;
                  }else{
                    //IL CAMPO È VUOTO, VADO AD INSERIRE LA PIANTA
                    if(acqua.quantita > 10 ){
                      //Inserisce la piantina
                      console.log("Inserisce la piantina");
                      bottone.style.backgroundImage = "url('img/semi/semeRosa.png')";
                      rosaVett.contatoreAcqua += 10;
                      acqua.quantita -= 10;
                      rosaVett.quantitaMinimaAcqua = 10;
                    }else{
                      //La quantita d'acqua non è sufficiente
                      console.log("Non ho acqua per piantare la pianta");
                      rosa.quantita++;
                    } 
                  }
                }
              }
            }
          }
        }
      }
    }
  //VADO AD EVOLVERE LA PIANTA, QUINDI RICORDA SARÀ UGUALE A OCCHIALI
  }else{
    //Vado a controllare se ricorda è "microfono"
    if(ricorda == "microfono"){
      microfono.quantita++;
    }else{
      //Vado a controllare se ricorda è un "cuore"
      if(ricorda == "cuore"){
        cuore.quantita++;
      }else{
        //Vado a controllare se ricorda è "sole"
        if(ricorda == "sole"){
          sole.quantita++;
        }else{
          //Se ho un seme Rosa e ricorda è uguale a occhiali vado avanti
          if(ricorda == "occhiali" && bottone.style.backgroundImage.includes('img/semi/semeRosa.png')){
            //Se l'acqua per evolverla è sufficente la evolvo
            if(rosaVett.controlloAcqua != true){
              bottone.style.backgroundImage = "url('img/shop/rosa.png')";
              rosaVett.contatoreAcqua += 10;
              acqua.quantita -=10;
              console.log("Evolve");
            }else{
              //L'acqua non è sufficente, quindi aumento occhiali.
              console.log("Non hai acqua");
              occhiali.quantita++;
            }
          }
        }
      }
    }
  }
}




//Pianta in B1
function piantaB1(){
    let bottone = document.getElementById("bottone1");
    let margheritaVett = vetB1[0];
    let tulipanoVett = vetB1[1];
    let girasoleVett = vetB1[2];
    let rosaVett = vetB1[3];
    
    //chiamo le funzioni di supporto
    if(ricorda == "margherita" || ricorda == "microfono"){
      chiamaMargherita(margheritaVett,bottone);
    }
    
    if(ricorda == "tulipano" || ricorda == "cuore"){
      chiamaTulipano(tulipanoVett,bottone);
    }
    
    if(ricorda == "girasole" || ricorda == "sole"){
      chiamaGirasole(girasoleVett,bottone);
    }

    if(ricorda == "rosa" || ricorda == "occhiali"){
      chiamaRosa(rosaVett,bottone);
    }
    

    //azzero ricorda
    ricorda = "";
}

//Pianta in B2
function piantaB2(){
  let bottone = document.getElementById("bottone2");
  let margheritaVett = vetB2[0];
  let tulipanoVett = vetB2[1];
  let girasoleVett = vetB2[2];
  let rosaVett = vetB2[3];
  
  //chiamo le funzioni di supporto
  if(ricorda == "margherita" || ricorda == "microfono"){
    chiamaMargherita(margheritaVett,bottone);
  }
  
  if(ricorda == "tulipano" || ricorda == "cuore"){
    chiamaTulipano(tulipanoVett,bottone);
  }
  
  if(ricorda == "girasole" || ricorda == "sole"){
    chiamaGirasole(girasoleVett,bottone);
  }

  if(ricorda == "rosa" || ricorda == "occhiali"){
    chiamaRosa(rosaVett,bottone);
  }

  //azzero ricorda
  ricorda = "";
}

//Pianta in B3
function piantaB3(){
  let bottone = document.getElementById("bottone3");
  let margheritaVett = vetB3[0];
  let tulipanoVett = vetB3[1];
  let girasoleVett = vetB3[2];
  let rosaVett = vetB3[3];
  
  //chiamo le funzioni di supporto
  if(ricorda == "margherita" || ricorda == "microfono"){
    chiamaMargherita(margheritaVett,bottone);
  }
  
  if(ricorda == "tulipano" || ricorda == "cuore"){
    chiamaTulipano(tulipanoVett,bottone);
  }
  
  if(ricorda == "girasole" || ricorda == "sole"){
    chiamaGirasole(girasoleVett,bottone);
  }

  if(ricorda == "rosa" || ricorda == "occhiali"){
    chiamaRosa(rosaVett,bottone);
  }

  //azzero ricorda
  ricorda = "";
}

//Pianta in B4
function piantaB4(){
  let bottone = document.getElementById("bottone4");
  let margheritaVett = vetB4[0];
  let tulipanoVett = vetB4[1];
  let girasoleVett = vetB4[2];
  let rosaVett = vetB4[3];
  
  //chiamo le funzioni di supporto
  if(ricorda == "margherita" || ricorda == "microfono"){
    chiamaMargherita(margheritaVett,bottone);
  }
  
  if(ricorda == "tulipano" || ricorda == "cuore"){
    chiamaTulipano(tulipanoVett,bottone);
  }
  
  if(ricorda == "girasole" || ricorda == "sole"){
    chiamaGirasole(girasoleVett,bottone);
  }

  if(ricorda == "rosa" || ricorda == "occhiali"){
    chiamaRosa(rosaVett,bottone);
  }

  //azzero ricorda
  ricorda = "";
}

//Pianta in B5
function piantaB5(){
  let bottone = document.getElementById("bottone5");
  let margheritaVett = vetB5[0];
  let tulipanoVett = vetB5[1];
  let girasoleVett = vetB5[2];
  let rosaVett = vetB5[3];
  
  //chiamo le funzioni di supporto
  if(ricorda == "margherita" || ricorda == "microfono"){
    chiamaMargherita(margheritaVett,bottone);
  }
  
  if(ricorda == "tulipano" || ricorda == "cuore"){
    chiamaTulipano(tulipanoVett,bottone);
  }
  
  if(ricorda == "girasole" || ricorda == "sole"){
    chiamaGirasole(girasoleVett,bottone);
  }

  if(ricorda == "rosa" || ricorda == "occhiali"){
    chiamaRosa(rosaVett,bottone);
  }

  //azzero ricorda
  ricorda = "";
}

//Pianta in B6
function piantaB6(){
  let bottone = document.getElementById("bottone6");
  let margheritaVett = vetB6[0];
  let tulipanoVett = vetB6[1];
  let girasoleVett = vetB6[2];
  let rosaVett = vetB6[3];
  
  //chiamo le funzioni di supporto
  if(ricorda == "margherita" || ricorda == "microfono"){
    chiamaMargherita(margheritaVett,bottone);
  }
  
  if(ricorda == "tulipano" || ricorda == "cuore"){
    chiamaTulipano(tulipanoVett,bottone);
  }
  
  if(ricorda == "girasole" || ricorda == "sole"){
    chiamaGirasole(girasoleVett,bottone);
  }

  if(ricorda == "rosa" || ricorda == "occhiali"){
    chiamaRosa(rosaVett,bottone);
  }

  //azzero ricorda
  ricorda = "";
}

//Pianta in B7
function piantaB7(){
  let bottone = document.getElementById("bottone7");
  let margheritaVett = vetB7[0];
  let tulipanoVett = vetB7[1];
  let girasoleVett = vetB7[2];
  let rosaVett = vetB7[3];
  
  //chiamo le funzioni di supporto
  if(ricorda == "margherita" || ricorda == "microfono"){
    chiamaMargherita(margheritaVett,bottone);
  }
  
  if(ricorda == "tulipano" || ricorda == "cuore"){
    chiamaTulipano(tulipanoVett,bottone);
  }
  
  if(ricorda == "girasole" || ricorda == "sole"){
    chiamaGirasole(girasoleVett,bottone);
  }

  if(ricorda == "rosa" || ricorda == "occhiali"){
    chiamaRosa(rosaVett,bottone);
  }

  //azzero ricorda
  ricorda = "";
}

//Pianta in B8
function piantaB8(){
  let bottone = document.getElementById("bottone8");
  let margheritaVett = vetB8[0];
  let tulipanoVett = vetB8[1];
  let girasoleVett = vetB8[2];
  let rosaVett = vetB8[3];
  
  //chiamo le funzioni di supporto
  if(ricorda == "margherita" || ricorda == "microfono"){
    chiamaMargherita(margheritaVett,bottone);
  }
  
  if(ricorda == "tulipano" || ricorda == "cuore"){
    chiamaTulipano(tulipanoVett,bottone);
  }
  
  if(ricorda == "girasole" || ricorda == "sole"){
    chiamaGirasole(girasoleVett,bottone);
  }

  if(ricorda == "rosa" || ricorda == "occhiali"){
    chiamaRosa(rosaVett,bottone);
  }

  //azzero ricorda
  ricorda = "";
}

//Pianta in B9
function piantaB9(){
  let bottone = document.getElementById("bottone9");
  let margheritaVett = vetB9[0];
  let tulipanoVett = vetB9[1];
  let girasoleVett = vetB9[2];
  let rosaVett = vetB9[3];
  
  //chiamo le funzioni di supporto
  if(ricorda == "margherita" || ricorda == "microfono"){
    chiamaMargherita(margheritaVett,bottone);
  }
  
  if(ricorda == "tulipano" || ricorda == "cuore"){
    chiamaTulipano(tulipanoVett,bottone);
  }
  
  if(ricorda == "girasole" || ricorda == "sole"){
    chiamaGirasole(girasoleVett,bottone);
  }

  if(ricorda == "rosa" || ricorda == "occhiali"){
    chiamaRosa(rosaVett,bottone);
  }

  //azzero ricorda
  ricorda = "";
}

//Pianta in B10
function piantaB10(){
  let bottone = document.getElementById("bottone10");
  let margheritaVett = vetB10[0];
  let tulipanoVett = vetB10[1];
  let girasoleVett = vetB10[2];
  let rosaVett = vetB10[3];
  
  //chiamo le funzioni di supporto
  if(ricorda == "margherita" || ricorda == "microfono"){
    chiamaMargherita(margheritaVett,bottone);
  }
  
  if(ricorda == "tulipano" || ricorda == "cuore"){
    chiamaTulipano(tulipanoVett,bottone);
  }
  
  if(ricorda == "girasole" || ricorda == "sole"){
    chiamaGirasole(girasoleVett,bottone);
  }

  if(ricorda == "rosa" || ricorda == "occhiali"){
    chiamaRosa(rosaVett,bottone);
  }

  //azzero ricorda
  ricorda = "";
}

//Pianta in B11
function piantaB11(){
  let bottone = document.getElementById("bottone11");
  let margheritaVett = vetB11[0];
  let tulipanoVett = vetB11[1];
  let girasoleVett = vetB11[2];
  let rosaVett = vetB11[3];
  
  //chiamo le funzioni di supporto
  if(ricorda == "margherita" || ricorda == "microfono"){
    chiamaMargherita(margheritaVett,bottone);
  }
  
  if(ricorda == "tulipano" || ricorda == "cuore"){
    chiamaTulipano(tulipanoVett,bottone);
  }
  
  if(ricorda == "girasole" || ricorda == "sole"){
    chiamaGirasole(girasoleVett,bottone);
  }

  if(ricorda == "rosa" || ricorda == "occhiali"){
    chiamaRosa(rosaVett,bottone);
  }

  //azzero ricorda
  ricorda = "";
}

//Pianta in B12
function piantaB12(){
  let bottone = document.getElementById("bottone12");
  let margheritaVett = vetB12[0];
  let tulipanoVett = vetB12[1];
  let girasoleVett = vetB12[2];
  let rosaVett = vetB12[3];
  
  //chiamo le funzioni di supporto
  if(ricorda == "margherita" || ricorda == "microfono"){
    chiamaMargherita(margheritaVett,bottone);
  }
  
  if(ricorda == "tulipano" || ricorda == "cuore"){
    chiamaTulipano(tulipanoVett,bottone);
  }
  
  if(ricorda == "girasole" || ricorda == "sole"){
    chiamaGirasole(girasoleVett,bottone);
  }

  if(ricorda == "rosa" || ricorda == "occhiali"){
    chiamaRosa(rosaVett,bottone);
  }

  //azzero ricorda
  ricorda = "";
}

//Pianta in B13
function piantaB13(){
  let bottone = document.getElementById("bottone13");
  let margheritaVett = vetB13[0];
  let tulipanoVett = vetB13[1];
  let girasoleVett = vetB13[2];
  let rosaVett = vetB13[3];
  
  //chiamo le funzioni di supporto
  if(ricorda == "margherita" || ricorda == "microfono"){
    chiamaMargherita(margheritaVett,bottone);
  }
  
  if(ricorda == "tulipano" || ricorda == "cuore"){
    chiamaTulipano(tulipanoVett,bottone);
  }
  
  if(ricorda == "girasole" || ricorda == "sole"){
    chiamaGirasole(girasoleVett,bottone);
  }

  if(ricorda == "rosa" || ricorda == "occhiali"){
    chiamaRosa(rosaVett,bottone);
  }

  //azzero ricorda
  ricorda = "";
}

//Pianta in B14
function piantaB14(){
  let bottone = document.getElementById("bottone14");
  let margheritaVett = vetB14[0];
  let tulipanoVett = vetB14[1];
  let girasoleVett = vetB14[2];
  let rosaVett = vetB14[3];
  
  //chiamo le funzioni di supporto
  if(ricorda == "margherita" || ricorda == "microfono"){
    chiamaMargherita(margheritaVett,bottone);
  }
  
  if(ricorda == "tulipano" || ricorda == "cuore"){
    chiamaTulipano(tulipanoVett,bottone);
  }
  
  if(ricorda == "girasole" || ricorda == "sole"){
    chiamaGirasole(girasoleVett,bottone);
  }

  if(ricorda == "rosa" || ricorda == "occhiali"){
    chiamaRosa(rosaVett,bottone);
  }

  //azzero ricorda
  ricorda = "";
}

//Pianta in B15
function piantaB15(){
  let bottone = document.getElementById("bottone15");
  let margheritaVett = vetB15[0];
  let tulipanoVett = vetB15[1];
  let girasoleVett = vetB15[2];
  let rosaVett = vetB15[3];
  
  //chiamo le funzioni di supporto
  if(ricorda == "margherita" || ricorda == "microfono"){
    chiamaMargherita(margheritaVett,bottone);
  }
  
  if(ricorda == "tulipano" || ricorda == "cuore"){
    chiamaTulipano(tulipanoVett,bottone);
  }
  
  if(ricorda == "girasole" || ricorda == "sole"){
    chiamaGirasole(girasoleVett,bottone);
  }

  if(ricorda == "rosa" || ricorda == "occhiali"){
    chiamaRosa(rosaVett,bottone);
  }

  //azzero ricorda
  ricorda = "";
}

//Pianta in B16
function piantaB16(){
  let bottone = document.getElementById("bottone16");
  let margheritaVett = vetB16[0];
  let tulipanoVett = vetB16[1];
  let girasoleVett = vetB16[2];
  let rosaVett = vetB16[3];
  
  //chiamo le funzioni di supporto
  if(ricorda == "margherita" || ricorda == "microfono"){
    chiamaMargherita(margheritaVett,bottone);
  }
  
  if(ricorda == "tulipano" || ricorda == "cuore"){
    chiamaTulipano(tulipanoVett,bottone);
  }
  
  if(ricorda == "girasole" || ricorda == "sole"){
    chiamaGirasole(girasoleVett,bottone);
  }

  if(ricorda == "rosa" || ricorda == "occhiali"){
    chiamaRosa(rosaVett,bottone);
  }

  //azzero ricorda
  ricorda = "";
}

//Funzione per i soldi
function visualizzaSoldi(){
  let elemSoldi = document.getElementById("soldiVisualizza");
  elemSoldi.textContent = "Soldi: " + soldi;
  elemSoldi.style.color = "yellow";
} setInterval(visualizzaSoldi, 10);

//Funzioner per i soldi sullo shop
function visualizzaSoldiShop(){
  let elemSoldi = document.getElementById("soldiVisualizzaShop");
  elemSoldi.textContent = "Soldi: " + soldi;
  elemSoldi.style.color = "yellow";
} setInterval(visualizzaSoldiShop, 10);

//Questo mi serve se cambio pagina, non mi ricompare il div cookies
if (click == true) {
  div.style.display = "block";
}


//Funzione per togliere la visibilità di del div cookies
function togliVisibilita(click) {
  let div = document.getElementById("cookies");
  if (div.style.display === "none") {
    div.style.display = "block"; // oppure "inline", "inline-block", a seconda delle tue esigenze
  } else {
    div.style.display = "none";
  }
  click = true;
  console.log(click);
}

//Funzione per tornare indietro di pagina
function goBack() {
  let elemShop = document.getElementById("corpoShop");
    elemShop.style.display = "none";
    
    let elemCorpo = document.getElementById("primaPagina");
    elemCorpo.style.display = "block";
  shopCliccato = false;
}

//Funzione per cambiare lo sfondo
function cambiaGiornoNotte() {
  let elem = document.getElementById("primaPagina");
  
  if (giorno == false) {
    document.getElementById("tempoGiorno").textContent = 'Tempo che manca al giorno: 10 secondi';
    document.getElementById("tempo")
    elem.style.background = "url('img/background_night.png')";
    elem.style.backgroundSize = "cover, contain";
    elem.style.backgroundPositionX = "10";
    elem.style.backgroundPositionY = "-200px";
    giorno = true;
  } else {
    document.getElementById("tempoGiorno").textContent = 'Tempo che manca alla notte: 10 secondi';
    console.log("Giorno");
    elem.style.background = "url('img/background_day.png')";
    elem.style.backgroundSize = "cover,contain";
    elem.style.backgroundPositionX = "0px";
    elem.style.backgroundPositionY = "-100px";
    giorno = false;
  }
}



//Funzione mostraTutorial
function mostraTutorial(){
  let elem = document.getElementById("tutorial");
  if(primaVolta == true){
    elem.style.display = "block";
    primaVolta = false;
  }else{
    elem.style.display = "none";
    primaVolta = true;
  }
}


//Funzione per mostrare l'inventario delle piante
function mostraPiante(){
  let elem = document.getElementById("inventarioPiante");
  if(primaVolta == true){
    elem.style.display = "block";
    primaVolta = false;
  }else{
    elem.style.display = "none";
    primaVolta = true;
  }
}

//Funzione per mostrare l'inventario degli item
function mostraItem(){
  let elem = document.getElementById("inventarioItem");
  if(primaVolta == true){
    elem.style.display = "block";
    primaVolta = false;
  }else{
    elem.style.display = "none";
    primaVolta = true;
  }
}

//Funzione che quando vado a cliccare lo shop, mi ferma il tempo
function fermaTempo(){
  shopCliccato = true;
}

//Funzione per mostrare lo shop
function mostraShop(){
  if(giorno == true){
    let elemShop = document.getElementById("corpoShop");
    elemShop.style.display = "block";
    
    let elemCorpo = document.getElementById("primaPagina");
    elemCorpo.style.display = "none";
  }else{
    console.log("Errore, è giorno");
  }

}

//Funzione per far apparire la quantità nell'inventario degli item

function inventarioItem(){
  let elemMic = document.getElementById("quantitaMicrofono");
  elemMic.textContent = "x" + microfono.quantita;

  let elemCuore = document.getElementById("quantitaCuore");
  elemCuore.textContent = "x" + cuore.quantita;

  let elemSole = document.getElementById("quantitaSole");
  elemSole.textContent = "x" +  sole.quantita;

  let elemOcchi = document.getElementById("quantitaOcchiali");
  elemOcchi.textContent = "x" +  occhiali.quantita;

  let elemAcqua = document.getElementById("quantitaAcqua");
  elemAcqua.textContent = "x" +  acqua.quantita;

  let elemVanga = document.getElementById("quantitaVanga");
  elemVanga.textContent = "x" + vanga.quantita;

} setInterval(inventarioItem, 100);



//Funzione per far apparire la quantità nell'inventario delle piante
function inventarioPiante(){
  let elemMarg = document.getElementById("quantitaMargherita");
  elemMarg.textContent = "x" + margherita.quantita;

  let elemTulip = document.getElementById("quantitaTulipano");
  elemTulip.textContent = "x" + tulipano.quantita;

  let elemGirasole = document.getElementById("quantitaGirasole");
  elemGirasole.textContent = "x" +  girasole.quantita;

  let elemRosa = document.getElementById("quantitaRosa");
  elemRosa.textContent = "x" +  rosa.quantita;

} setInterval(inventarioPiante, 100);



//FUNZIONI RICORDA INVENTARIO E ITEM

//Funzione per ricordare il fiore che ho selezionato dall'inventario (Margherita)
function ricordaMargherita(){
  if(ricorda == "margherita"){
    console.log("Hai già selezionato una Margherita");
  }else{
    if(margherita.quantita > 0 ){
      ricorda = "margherita";
      margherita.quantita--;
    }else{
      console.log("Non hai abbastanza Margherite");
      ricorda = null;
    }
  }
}

//Funzione per ricordare il fiore che ho selezionato dall'inventario (Tulipano)
function ricordaTulipano(){
  if(ricorda == "tulipano"){
    console.log("Hai già selezionato un tulipano");
  }else{
    if(tulipano.quantita > 0 ){
      ricorda = "tulipano";
      tulipano.quantita--;
    }else{
      ricorda = null;
      console.log("Non hai abbastanza Tulipani");
    }
  }
}

//Funzione per ricordare il fiore che ho selezionato dall'inventario (Girasole)
function ricordaGirasole(){
  if(ricorda == "girasole"){
    console.log("Hai già selezionato un girasole");
  }else{
    if(girasole.quantita > 0 ){
      ricorda = "girasole";
      girasole.quantita--;
    }else{
      ricorda = null;
      console.log("Non hai abbastanza Girasoli");
    }
  }
}

//Funzione per ricordare il fiore che ho selezionato dall'inventario (Rosa)
function ricordaRosa(){
  if(ricorda == "rosa"){
    console.log("Hai già selezionato una rosa");
  }else{
    if(rosa.quantita > 0 ){
      ricorda = "rosa";
      rosa.quantita--;
    }else{
      ricorda = null;
      console.log("Non hai abbastanza Rose");
    }
  }
}

//Funzione per ricordare l'item che ho selezionato dall'inventario (Microfono)
function ricordaMicrofono(){
  if(ricorda == "microfono"){
    console.log("Hai già selezionato un microfono");
  }else{
    if(microfono.quantita > 0){
      ricorda = "microfono";
      microfono.quantita--;
    }else{
      ricorda = null;
      console.log("Non hai abbastanza microfoni");
    }
  }
}

//Funzione per ricordare l'item che ho selezionato dall'inventario (Cuore)
function ricordaCuore(){
  if(ricorda == "cuore"){
    console.log("Hai già selezionato un cuore");
  }else{
    if(cuore.quantita > 0){
      ricorda = "cuore";
      cuore.quantita--;
    }else{
      ricorda = null;
      console.log("Non hai abbastanza cuori");
    }
  }
}

//Funzione per ricordare l'item che ho selezionato dall'inventario (Sole)
function ricordaSole(){
  if(ricorda == "sole"){
    console.log("Hai già selezionato un sole");
  }else{
    if(cuore.quantita > 0){
      ricorda = "sole";
      sole.quantita--;
    }else{
      ricorda = null;
      console.log("Non hai abbastanza soli");
    }
  }
}

//Funzione per ricordare l'item che ho selezionato dall'inventario (Occhiali)
function ricordaOcchiali(){
  if(ricorda == "occhiali"){
    console.log("Hai già selezionato degli occhiali");
  }else{
    if(occhiali.quantita > 0){
      ricorda = "occhiali";
      occhiali.quantita--;
    }else{
      ricorda = null;
      console.log("Non hai abbastanza occhiali");
    }
  }
}

//Funzione per ricorda l'item che ho selezionato dall'inventario (Vanga)
function ricordaVanga(){
  if(ricorda == "vanga"){
    console.log("Hai già selezionato una vanga");
  }else{
    if(vanga.quantita > 0){
      ricorda = "vanga";
      vanga.quantita--;
    }else{
      ricorda = null;
      console.log("Non hai abbastanza vanghe")
    }
  }
}


