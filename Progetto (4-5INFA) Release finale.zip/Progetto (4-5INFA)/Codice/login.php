<?php
session_start();


require_once'config.php';
$conn = new mysqli(
    $config['mysql_host'],
    $config['mysql_user'],
    $config['mysql_password'],
    $config['mysql_db']
);
if($conn->connect_error)
die("Errore connesione al database.<br>");

   
    if (isset($_POST["username"]) && isset($_POST["password"])) {

  
    $username = mysqli_real_escape_string($db, $_POST["username"]);
    $password = mysqli_real_escape_string($db, $_POST["password"]);






   
    $query = "SELECT * FROM users WHERE username='$username' AND password=md5('$password')";
    $result = mysqli_query($db, $query);

    if (mysqli_num_rows($result) == 1) {
       
        $_SESSION["username"] = $username;

      
        setcookie("username", $username, time() + (86400 * 30), "/");

        header("Location: index.html");
    } 
    else {
      
        echo "Username o password non validi";
    }
    
}
$connessione->close();
?>