<?php
$config = [
    'mysql_host' => 'localhost',
    'mysql_user' => 'marco',
    'mysql_password' => null,
    'mysql_db' => 'Prato_Crescita_Fiore'];

?>