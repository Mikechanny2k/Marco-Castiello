<?php
session_start();


require_once 'config.php';
$conn = new mysqli(
    $config['mysql_host'],
    $config['mysql_user'],
    $config['mysql_password'],
    $config['mysql_db']
);
if ($conn->connect_error)
    die("Errore connesione al database.<br>");


if(isset($_SESSION['Io']) && $_SESSION['register'] === true){
    header("Location: index.html"); 
    exit;
}


$registerErr = "";
$registerSuccess = "";


if($_SERVER["REQUEST_METHOD"] == "POST"){
  
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];


    if(empty($username) || empty($email) || empty($password)){
        $registerErr = "I campi Username, Email e Password sono obbligatori!";
    } else {
   
        $sql = "INSERT INTO Registrazione (Username, email, password) VALUES (?, ?, ?)";

        if($stmt = $conn->prepare($sql)){
            $stmt->bind_param("sss", $username, $email, $password);

            if($stmt->execute()){
                $registerSuccess = "Registrazione effettuata con successo!, Benvenuto!";

               
                $_SESSION['register'] = true;
                $_SESSION['username'] = $username;

                header("Location: index.html");
            } else {
                $registerErr = "Errore registrazione. Riprova piu' tardi.";
            }
        }

       
        $stmt->close();
    }
    $conn->close();
}
?>


